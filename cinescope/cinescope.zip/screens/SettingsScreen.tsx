import React from 'react';
import {
  View, Text, StyleSheet, ScrollView,
  TouchableOpacity, Linking, Alert,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { CONFIG } from '../config';

interface SettingsRow {
  icon: string;
  label: string;
  action: () => void;
  value?: string;
}

export default function SettingsScreen() {
  const insets = useSafeAreaInsets();

  const openLink = (url: string) => Linking.openURL(url);

  const rows: SettingsRow[] = [
    {
      icon: '📡',
      label: 'API Server',
      value: CONFIG.APP_URL.replace('http://', '').replace('https://', ''),
      action: () =>
        Alert.alert('API Server', `Connected to:\n${CONFIG.APP_URL}`, [{ text: 'OK' }]),
    },
    {
      icon: '🔒',
      label: 'Privacy Policy',
      action: () => openLink('https://www.themoviedb.org/privacy-policy'),
    },
    {
      icon: '⭐',
      label: 'Rate the App',
      action: () =>
        Alert.alert('Rate MovieBox', 'Thanks for using the app! Share it with friends 🎬', [
          { text: 'OK' },
        ]),
    },
    {
      icon: '📱',
      label: 'App Version',
      value: '2.0.0 (Native)',
      action: () =>
        Alert.alert('MovieBox', 'Version 2.0.0\nBuilt with React Native + Expo\n\nYour personal streaming companion.', [
          { text: 'OK' },
        ]),
    },
  ];

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      <StatusBar style="light" />
      <Text style={styles.header}>Settings</Text>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 100 }}>

        {/* App info card */}
        <View style={styles.heroCard}>
          <View style={styles.logoCircle}>
            <Text style={styles.logoEmoji}>🎬</Text>
          </View>
          <Text style={styles.appName}>MovieBox</Text>
          <Text style={styles.appTagline}>Your Personal Streaming Companion</Text>
          <View style={styles.pillRow}>
            <View style={styles.pill}><Text style={styles.pillText}>🎥 Movies</Text></View>
            <View style={styles.pill}><Text style={styles.pillText}>📺 TV Shows</Text></View>
            <View style={styles.pill}><Text style={styles.pillText}>🌐 Anime</Text></View>
          </View>
        </View>

        {/* Settings Rows */}
        <View style={styles.card}>
          {rows.map((row, i) => (
            <TouchableOpacity
              key={row.label}
              style={[
                styles.row,
                i < rows.length - 1 && styles.rowBorder,
              ]}
              onPress={row.action}
              activeOpacity={0.7}
            >
              <Text style={styles.rowIcon}>{row.icon}</Text>
              <View style={styles.rowContent}>
                <Text style={styles.rowLabel}>{row.label}</Text>
                {row.value ? (
                  <Text style={styles.rowValue} numberOfLines={1}>{row.value}</Text>
                ) : null}
              </View>
              <Text style={styles.chevron}>›</Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Quality info */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>Streaming Quality</Text>
          <View style={styles.qualityRow}>
            {[
              { label: '4K', sub: 'Ultra HD' },
              { label: '1080p', sub: 'Full HD' },
              { label: '720p', sub: 'HD' },
            ].map(q => (
              <View key={q.label} style={styles.qualityChip}>
                <Text style={styles.qualityLabel}>{q.label}</Text>
                <Text style={styles.qualitySub}>{q.sub}</Text>
              </View>
            ))}
          </View>
          <Text style={styles.qualityNote}>
            Streams are automatically selected based on server availability and your connection.
          </Text>
        </View>

        {/* Disclaimer */}
        <View style={styles.disclaimer}>
          <Text style={styles.disclaimerText}>
            MovieBox aggregates publicly available streaming links. We do not host any video files.
            All content is sourced from third-party providers.
          </Text>
        </View>

      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: CONFIG.COLORS.bg,
    paddingHorizontal: 16,
  },
  header: {
    fontSize: 28,
    fontWeight: '800',
    color: '#FFFFFF',
    marginTop: 16,
    marginBottom: 20,
  },

  // Hero card
  heroCard: {
    backgroundColor: CONFIG.COLORS.card,
    borderRadius: 18,
    padding: 24,
    alignItems: 'center',
    marginBottom: 14,
    borderWidth: 1,
    borderColor: 'rgba(229,9,20,0.15)',
  },
  logoCircle: {
    width: 80,
    height: 80,
    borderRadius: 24,
    backgroundColor: CONFIG.COLORS.accent,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 14,
    shadowColor: CONFIG.COLORS.accent,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.5,
    shadowRadius: 16,
    elevation: 12,
  },
  logoEmoji: { fontSize: 38 },
  appName: {
    fontSize: 24,
    fontWeight: '900',
    color: '#fff',
    marginBottom: 4,
  },
  appTagline: {
    fontSize: 13,
    color: CONFIG.COLORS.textSecondary,
    marginBottom: 14,
  },
  pillRow: { flexDirection: 'row', gap: 8 },
  pill: {
    backgroundColor: 'rgba(229,9,20,0.12)',
    borderRadius: 20,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderWidth: 1,
    borderColor: 'rgba(229,9,20,0.25)',
  },
  pillText: { color: CONFIG.COLORS.accent, fontSize: 11, fontWeight: '700' },

  // Settings card
  card: {
    backgroundColor: CONFIG.COLORS.card,
    borderRadius: 14,
    padding: 4,
    marginBottom: 14,
  },
  cardTitle: {
    fontSize: 12,
    fontWeight: '700',
    color: CONFIG.COLORS.textSecondary,
    textTransform: 'uppercase',
    letterSpacing: 1,
    paddingHorizontal: 14,
    paddingTop: 12,
    paddingBottom: 10,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 14,
    paddingVertical: 14,
    gap: 12,
  },
  rowBorder: {
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255,255,255,0.06)',
  },
  rowIcon: { fontSize: 20, width: 28, textAlign: 'center' },
  rowContent: { flex: 1 },
  rowLabel: { color: '#fff', fontSize: 15, fontWeight: '600' },
  rowValue: {
    color: CONFIG.COLORS.textSecondary,
    fontSize: 12,
    marginTop: 2,
    fontFamily: 'monospace',
  },
  chevron: { color: '#444', fontSize: 22 },

  // Quality
  qualityRow: {
    flexDirection: 'row',
    gap: 10,
    paddingHorizontal: 14,
    paddingBottom: 12,
  },
  qualityChip: {
    flex: 1,
    backgroundColor: 'rgba(229,9,20,0.1)',
    borderRadius: 10,
    padding: 10,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(229,9,20,0.2)',
  },
  qualityLabel: { color: CONFIG.COLORS.accent, fontSize: 14, fontWeight: '800' },
  qualitySub: { color: CONFIG.COLORS.textSecondary, fontSize: 10, marginTop: 2 },
  qualityNote: {
    color: '#52525b',
    fontSize: 11,
    lineHeight: 17,
    paddingHorizontal: 14,
    paddingBottom: 14,
  },

  // Disclaimer
  disclaimer: {
    padding: 16,
    borderRadius: 12,
    backgroundColor: 'rgba(255,255,255,0.03)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.06)',
    marginBottom: 14,
  },
  disclaimerText: {
    color: '#3f3f46',
    fontSize: 11,
    lineHeight: 18,
    textAlign: 'center',
  },
});
