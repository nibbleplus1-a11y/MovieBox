import React, { useEffect, useState, useRef, useCallback } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet,
  ActivityIndicator, Dimensions, ScrollView, Modal,
  TouchableWithoutFeedback, Animated,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useNavigation, useRoute } from '@react-navigation/native';
import { WebView } from 'react-native-webview';
import * as ScreenOrientation from 'expo-screen-orientation';
import { CONFIG } from '../config';
import { api, StreamData, StreamSource } from '../services/api';

const { width: SCREEN_WIDTH, height: SCREEN_HEIGHT } = Dimensions.get('window');

type BottomSheetType = 'none' | 'audio' | 'quality' | 'speed' | 'episodes' | 'servers';

export default function PlayerScreen() {
  const insets = useSafeAreaInsets();
  const navigation = useNavigation<any>();
  const route = useRoute<any>();
  const {
    id: initialId,
    title,
    cover,
    initialDub,
    season: initialSeason = 0,
    episode: initialEpisode = 0,
    type: initialType = 'Movie',
  } = route.params || {};

  // Core stream states
  const [currentId, setCurrentId] = useState<string>(initialId);
  const [currentSeason, setCurrentSeason] = useState<number>(initialSeason);
  const [currentEpisode, setCurrentEpisode] = useState<number>(initialEpisode);
  const [streamData, setStreamData] = useState<StreamData | null>(null);
  const [activeStream, setActiveStream] = useState<StreamSource | null>(null);
  const [selectedServer, setSelectedServer] = useState<string>('direct');
  const [streamUrl, setStreamUrl] = useState<string>('');
  const [useIframe, setUseIframe] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  // Playback states
  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [duration, setDuration] = useState<number>(0);
  const [isBuffering, setIsBuffering] = useState<boolean>(true);
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1.0);
  const [selectedDubName, setSelectedDubName] = useState<string>(initialDub || 'Original Audio');

  // UI Control states (Netflix-style)
  const [controlsVisible, setControlsVisible] = useState<boolean>(true);
  const [isLocked, setIsLocked] = useState<boolean>(false);
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);
  const [bottomSheet, setBottomSheet] = useState<BottomSheetType>('none');
  const [seasonsData, setSeasonsData] = useState<any[]>([]);

  const webViewRef = useRef<any>(null);
  const controlsTimerRef = useRef<any>(null);
  const fadeAnim = useRef(new Animated.Value(1)).current;

  // Format seconds to mm:ss or hh:mm:ss
  const formatTime = (seconds: number) => {
    if (isNaN(seconds) || seconds < 0) return '00:00';
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = Math.floor(seconds % 60);
    if (hrs > 0) {
      return `${hrs}:${mins < 10 ? '0' : ''}${mins}:${secs < 10 ? '0' : ''}${secs}`;
    }
    return `${mins < 10 ? '0' : ''}${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  // Lock to portrait by default, restore on unmount
  useEffect(() => {
    ScreenOrientation.lockAsync(ScreenOrientation.OrientationLock.PORTRAIT_UP);
    return () => {
      ScreenOrientation.lockAsync(ScreenOrientation.OrientationLock.PORTRAIT_UP);
    };
  }, []);

  // Auto-hide controls timer (Netflix 3.5s rule)
  const resetControlsTimer = useCallback(() => {
    if (controlsTimerRef.current) clearTimeout(controlsTimerRef.current);
    setControlsVisible(true);
    Animated.timing(fadeAnim, { toValue: 1, duration: 200, useNativeDriver: true }).start();

    if (!isLocked && isPlaying) {
      controlsTimerRef.current = setTimeout(() => {
        Animated.timing(fadeAnim, { toValue: 0, duration: 300, useNativeDriver: true }).start(() => {
          setControlsVisible(false);
        });
      }, 3500);
    }
  }, [fadeAnim, isLocked, isPlaying]);

  useEffect(() => {
    resetControlsTimer();
    return () => {
      if (controlsTimerRef.current) clearTimeout(controlsTimerRef.current);
    };
  }, [resetControlsTimer, isPlaying]);

  // Toggle controls visibility on single tap
  const toggleControls = () => {
    if (controlsVisible) {
      Animated.timing(fadeAnim, { toValue: 0, duration: 200, useNativeDriver: true }).start(() => {
        setControlsVisible(false);
      });
      if (controlsTimerRef.current) clearTimeout(controlsTimerRef.current);
    } else {
      resetControlsTimer();
    }
  };

  // Fullscreen toggle handler
  const toggleFullscreen = useCallback(async () => {
    if (isFullscreen) {
      await ScreenOrientation.lockAsync(ScreenOrientation.OrientationLock.PORTRAIT_UP);
      setIsFullscreen(false);
    } else {
      await ScreenOrientation.lockAsync(ScreenOrientation.OrientationLock.LANDSCAPE_RIGHT);
      setIsFullscreen(true);
    }
    resetControlsTimer();
  }, [isFullscreen, resetControlsTimer]);

  // Load streams from backend
  const loadStreams = useCallback(async (subjectId: string, se = 0, ep = 0) => {
    setLoading(true);
    setError(null);
    try {
      const data = await api.streams(subjectId, se, ep);
      setStreamData(data);

      const playable = (data.streams || []).filter(
        s => s.format !== 'DASH' && !s.url.includes('.mpd')
      );

      if (playable.length > 0) {
        const best = playable.find(s => s.quality === '1080p') || playable[0];
        setActiveStream(best);
        setSelectedServer('direct');
        setUseIframe(false);
        setStreamUrl(api.proxyUrl(best.url, best.headers?.Referer));
      } else if (data.fallback_servers && data.fallback_servers.length > 0) {
        const srv = data.fallback_servers[0];
        setSelectedServer(srv.id);
        setStreamUrl(srv.url);
        setUseIframe(true);
      } else {
        setError('No direct streams or backup servers available.');
      }

      // Fetch episodes if series
      if (initialType === 'Series' || initialType === 'TV Series' || se > 0 || ep > 0) {
        try {
          const epData = await api.episodes(subjectId);
          if (epData?.seasons) setSeasonsData(epData.seasons);
        } catch {}
      }
    } catch (err: any) {
      setError(err?.message || 'Failed to load video stream');
    } finally {
      setLoading(false);
    }
  }, [initialType]);

  useEffect(() => {
    loadStreams(currentId, currentSeason, currentEpisode);
  }, [currentId, currentSeason, currentEpisode, loadStreams]);

  // Control Commands to WebView Video
  const sendVideoCommand = (jsCode: string) => {
    if (webViewRef.current) {
      webViewRef.current.injectJavaScript(jsCode);
    }
  };

  const togglePlayPause = () => {
    if (isPlaying) {
      sendVideoCommand('window.videoEl && window.videoEl.pause();');
    } else {
      sendVideoCommand('window.videoEl && window.videoEl.play();');
    }
    resetControlsTimer();
  };

  const seekRelative = (deltaSeconds: number) => {
    const target = Math.max(0, Math.min(duration, currentTime + deltaSeconds));
    sendVideoCommand(`if(window.videoEl) window.videoEl.currentTime = ${target};`);
    setCurrentTime(target);
    resetControlsTimer();
  };

  const seekAbsolute = (percentage: number) => {
    if (duration > 0) {
      const target = duration * Math.max(0, Math.min(1, percentage));
      sendVideoCommand(`if(window.videoEl) window.videoEl.currentTime = ${target};`);
      setCurrentTime(target);
      resetControlsTimer();
    }
  };

  const changeSpeed = (speed: number) => {
    setPlaybackSpeed(speed);
    sendVideoCommand(`if(window.videoEl) window.videoEl.playbackRate = ${speed};`);
    setBottomSheet('none');
    resetControlsTimer();
  };

  const switchQuality = (stream: StreamSource) => {
    setActiveStream(stream);
    setSelectedServer('direct');
    setUseIframe(false);
    const newUrl = api.proxyUrl(stream.url, stream.headers?.Referer);
    setStreamUrl(newUrl);
    setBottomSheet('none');
    resetControlsTimer();
  };

  const switchDub = (dubId: string, dubName: string) => {
    setSelectedDubName(dubName);
    setCurrentId(dubId);
    setBottomSheet('none');
    resetControlsTimer();
  };

  const switchServer = (serverId: string) => {
    if (serverId === 'direct') {
      if (activeStream) {
        setSelectedServer('direct');
        setUseIframe(false);
        setStreamUrl(api.proxyUrl(activeStream.url, activeStream.headers?.Referer));
      }
    } else {
      const srv = streamData?.fallback_servers?.find(s => s.id === serverId);
      if (srv) {
        setSelectedServer(srv.id);
        setUseIframe(true);
        setStreamUrl(srv.url);
      }
    }
    setBottomSheet('none');
    resetControlsTimer();
  };

  const switchEpisode = (se: number, ep: number) => {
    setCurrentSeason(se);
    setCurrentEpisode(ep);
    setBottomSheet('none');
    resetControlsTimer();
  };

  // Handle messages from the WebView Video Player
  const handleWebViewMessage = (event: any) => {
    try {
      const msg = JSON.parse(event.nativeEvent.data);
      switch (msg.type) {
        case 'timeupdate':
          setCurrentTime(msg.currentTime || 0);
          if (msg.duration && msg.duration > 0) setDuration(msg.duration);
          break;
        case 'playing':
          setIsPlaying(true);
          setIsBuffering(false);
          break;
        case 'pause':
          setIsPlaying(false);
          break;
        case 'waiting':
          setIsBuffering(true);
          break;
        case 'canplay':
          setIsBuffering(false);
          break;
        default:
          break;
      }
    } catch {}
  };

  // Custom HTML5 Video Player inside WebView (Zero Browser UI, Pure Netflix Engine)
  const buildPlayerHTML = (videoSrc: string) => `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" />
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    html, body {
      width: 100%; height: 100%;
      background: #000; overflow: hidden;
      user-select: none; -webkit-user-select: none;
    }
    video {
      width: 100%; height: 100%;
      object-fit: contain; background: #000;
      pointer-events: none;
    }
  </style>
</head>
<body>
  <video
    id="videoPlayer"
    autoplay
    playsinline
    webkit-playsinline
    x5-playsinline="true"
    preload="auto"
  >
    <source src="${videoSrc}" type="video/mp4" />
  </video>

  <script>
    const v = document.getElementById('videoPlayer');
    window.videoEl = v;

    function post(obj) {
      if (window.ReactNativeWebView && window.ReactNativeWebView.postMessage) {
        window.ReactNativeWebView.postMessage(JSON.stringify(obj));
      }
    }

    v.addEventListener('timeupdate', () => {
      post({ type: 'timeupdate', currentTime: v.currentTime, duration: v.duration });
    });
    v.addEventListener('playing', () => post({ type: 'playing' }));
    v.addEventListener('pause', () => post({ type: 'pause' }));
    v.addEventListener('waiting', () => post({ type: 'waiting' }));
    v.addEventListener('canplay', () => post({ type: 'canplay' }));
    v.addEventListener('ended', () => post({ type: 'ended' }));
  </script>
</body>
</html>
`;

  const playableStreams = (streamData?.streams || []).filter(
    s => s.format !== 'DASH' && !s.url.includes('.mpd')
  );
  const dubsList = streamData?.dubs || [];
  const fallbackServers = streamData?.fallback_servers || [];
  const currentSeasonEpisodes = seasonsData.find(s => s.season === currentSeason)?.episodes || [];

  const playerHeight = isFullscreen ? SCREEN_HEIGHT : (SCREEN_WIDTH * 9) / 16;
  const progressRatio = duration > 0 ? Math.min(1, Math.max(0, currentTime / duration)) : 0;

  return (
    <View style={[styles.container, isFullscreen && styles.containerFullscreen]}>
      <StatusBar hidden={isFullscreen} style="light" />

      {/* VIDEO PLAYER VIEWPORT */}
      <View style={[styles.playerContainer, { height: playerHeight }]}>
        {loading ? (
          <View style={styles.centerBox}>
            <ActivityIndicator size="large" color="#e50914" />
            <Text style={styles.loadingText}>Connecting 1080p stream…</Text>
          </View>
        ) : error ? (
          <View style={styles.centerBox}>
            <Text style={styles.errorIcon}>⚠️</Text>
            <Text style={styles.errorText}>{error}</Text>
            <TouchableOpacity
              style={styles.retryBtn}
              onPress={() => loadStreams(currentId, currentSeason, currentEpisode)}
            >
              <Text style={styles.retryText}>Retry Stream</Text>
            </TouchableOpacity>
          </View>
        ) : useIframe ? (
          <WebView
            key={streamUrl}
            source={{ uri: streamUrl }}
            style={styles.webview}
            allowsFullscreenVideo
            mediaPlaybackRequiresUserAction={false}
            allowsInlineMediaPlayback
            javaScriptEnabled
            domStorageEnabled
          />
        ) : (
          <WebView
            ref={webViewRef}
            key={streamUrl}
            source={{ html: buildPlayerHTML(streamUrl) }}
            style={styles.webview}
            allowsFullscreenVideo
            mediaPlaybackRequiresUserAction={false}
            allowsInlineMediaPlayback
            javaScriptEnabled
            domStorageEnabled
            scrollEnabled={false}
            onMessage={handleWebViewMessage}
          />
        )}

        {/* Buffering Indicator overlay */}
        {isBuffering && !loading && !error && !useIframe && (
          <View style={styles.bufferingOverlay} pointerEvents="none">
            <ActivityIndicator size="large" color="#e50914" />
          </View>
        )}

        {/* GESTURE TOUCH LAYER (Tapping toggles controls) */}
        {!useIframe && !loading && !error && (
          <TouchableWithoutFeedback onPress={toggleControls}>
            <View style={StyleSheet.absoluteFill} />
          </TouchableWithoutFeedback>
        )}

        {/* NETFLIX-STYLE FLOATING ON-SCREEN CONTROLS OVERLAY */}
        {!useIframe && !loading && !error && controlsVisible && (
          <Animated.View
            style={[StyleSheet.absoluteFill, styles.controlsOverlay, { opacity: fadeAnim }]}
            pointerEvents="box-none"
          >
            {/* Screen Lock Mode */}
            {isLocked ? (
              <View style={styles.lockedContainer}>
                <TouchableOpacity
                  style={styles.unlockBtn}
                  onPress={() => { setIsLocked(false); resetControlsTimer(); }}
                  activeOpacity={0.8}
                >
                  <Text style={styles.unlockIcon}>🔒</Text>
                  <Text style={styles.unlockText}>Screen Locked • Tap to Unlock</Text>
                </TouchableOpacity>
              </View>
            ) : (
              <>
                {/* TOP BAR */}
                <View style={[styles.topBar, { paddingTop: isFullscreen ? insets.top + 8 : 12 }]}>
                  <TouchableOpacity
                    style={styles.iconCircleBtn}
                    onPress={() => isFullscreen ? toggleFullscreen() : navigation.goBack()}
                    activeOpacity={0.8}
                  >
                    <Text style={styles.iconCircleText}>‹</Text>
                  </TouchableOpacity>

                  <View style={styles.topTitleBox}>
                    <Text style={styles.topMovieTitle} numberOfLines={1}>
                      {title || streamData?.title || 'Now Playing'}
                    </Text>
                    <Text style={styles.topMovieSubtitle} numberOfLines={1}>
                      {selectedDubName} • {activeStream?.quality || '1080p FHD'}
                    </Text>
                  </View>

                  <View style={styles.topRightIcons}>
                    <TouchableOpacity
                      style={styles.toolChip}
                      onPress={() => { setBottomSheet('audio'); resetControlsTimer(); }}
                    >
                      <Text style={styles.toolChipText}>🔊 Audio</Text>
                    </TouchableOpacity>

                    <TouchableOpacity
                      style={styles.toolChip}
                      onPress={() => { setBottomSheet('quality'); resetControlsTimer(); }}
                    >
                      <Text style={styles.toolChipText}>⚡ Quality</Text>
                    </TouchableOpacity>

                    <TouchableOpacity
                      style={styles.lockIconBtn}
                      onPress={() => { setIsLocked(true); resetControlsTimer(); }}
                    >
                      <Text style={styles.lockIconText}>🔓</Text>
                    </TouchableOpacity>
                  </View>
                </View>

                {/* CENTER CONTROLS: -10s, Play/Pause, +10s */}
                <View style={styles.centerControls} pointerEvents="box-none">
                  <TouchableOpacity
                    style={styles.seekBtn}
                    onPress={() => seekRelative(-10)}
                    activeOpacity={0.7}
                  >
                    <Text style={styles.seekBtnIcon}>↺</Text>
                    <Text style={styles.seekBtnSub}>10</Text>
                  </TouchableOpacity>

                  <TouchableOpacity
                    style={styles.playPauseBtn}
                    onPress={togglePlayPause}
                    activeOpacity={0.85}
                  >
                    <Text style={styles.playPauseIcon}>{isPlaying ? '⏸' : '▶'}</Text>
                  </TouchableOpacity>

                  <TouchableOpacity
                    style={styles.seekBtn}
                    onPress={() => seekRelative(10)}
                    activeOpacity={0.7}
                  >
                    <Text style={styles.seekBtnIcon}>↻</Text>
                    <Text style={styles.seekBtnSub}>10</Text>
                  </TouchableOpacity>
                </View>

                {/* BOTTOM CONTROLS: Scrubber & Quick Tools */}
                <View style={[styles.bottomBar, { paddingBottom: isFullscreen ? insets.bottom + 8 : 10 }]}>
                  {/* Scrubber Bar */}
                  <View style={styles.scrubberRow}>
                    <Text style={styles.timeText}>{formatTime(currentTime)}</Text>
                    <TouchableWithoutFeedback
                      onPress={(e) => {
                        const touchX = e.nativeEvent.locationX;
                        // Approximate progress tap
                        seekAbsolute(touchX / (SCREEN_WIDTH - 120));
                      }}
                    >
                      <View style={styles.scrubberTrack}>
                        <View style={[styles.scrubberFill, { width: `${progressRatio * 100}%` }]} />
                        <View style={styles.scrubberThumb} />
                      </View>
                    </TouchableWithoutFeedback>
                    <Text style={styles.timeText}>{formatTime(duration)}</Text>
                  </View>

                  {/* Feature Tray */}
                  <View style={styles.bottomTray}>
                    <View style={styles.bottomTrayLeft}>
                      <TouchableOpacity
                        style={styles.trayActionBtn}
                        onPress={() => { setBottomSheet('speed'); resetControlsTimer(); }}
                      >
                        <Text style={styles.trayActionText}>Speed ({playbackSpeed}x)</Text>
                      </TouchableOpacity>

                      <TouchableOpacity
                        style={styles.trayActionBtn}
                        onPress={() => { setBottomSheet('servers'); resetControlsTimer(); }}
                      >
                        <Text style={styles.trayActionText}>☁️ Server</Text>
                      </TouchableOpacity>

                      {seasonsData.length > 0 && (
                        <TouchableOpacity
                          style={styles.trayActionBtn}
                          onPress={() => { setBottomSheet('episodes'); resetControlsTimer(); }}
                        >
                          <Text style={styles.trayActionText}>📺 Episodes</Text>
                        </TouchableOpacity>
                      )}
                    </View>

                    <TouchableOpacity style={styles.fullscreenToggle} onPress={toggleFullscreen}>
                      <Text style={styles.fullscreenToggleText}>{isFullscreen ? '⤓' : '⤢'}</Text>
                    </TouchableOpacity>
                  </View>
                </View>
              </>
            )}
          </Animated.View>
        )}
      </View>

      {/* PORTRAIT DASHBOARD & RECOMMENDATIONS (Smooth scrolling) */}
      {!isFullscreen && (
        <ScrollView
          style={styles.scrollArea}
          contentContainerStyle={styles.scrollContent}
          showsVerticalScrollIndicator={false}
          bounces
        >
          {/* Movie Title & Badges */}
          <View style={styles.metaSection}>
            <Text style={styles.movieMainTitle}>{title || streamData?.title || 'Now Playing'}</Text>
            
            <View style={styles.badgeRow}>
              <View style={styles.netflixMatchBadge}>
                <Text style={styles.netflixMatchText}>98% Match</Text>
              </View>
              <View style={styles.qualityTagBadge}>
                <Text style={styles.qualityTagText}>{activeStream?.quality || '1080p FHD'}</Text>
              </View>
              <View style={styles.metaTagBadge}>
                <Text style={styles.metaTagText}>Dolby Audio</Text>
              </View>
              <View style={styles.metaTagBadge}>
                <Text style={styles.metaTagText}>{selectedDubName}</Text>
              </View>
            </View>
          </View>

          {/* Quick Actions Row */}
          <View style={styles.quickBar}>
            <TouchableOpacity
              style={styles.quickBtn}
              onPress={() => setBottomSheet('audio')}
              activeOpacity={0.8}
            >
              <Text style={styles.quickBtnIcon}>🔊</Text>
              <Text style={styles.quickBtnLabel}>Audio Dubs</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.quickBtn}
              onPress={() => setBottomSheet('quality')}
              activeOpacity={0.8}
            >
              <Text style={styles.quickBtnIcon}>⚡</Text>
              <Text style={styles.quickBtnLabel}>Quality</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.quickBtn}
              onPress={() => setBottomSheet('servers')}
              activeOpacity={0.8}
            >
              <Text style={styles.quickBtnIcon}>☁️</Text>
              <Text style={styles.quickBtnLabel}>Servers</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.quickBtn}
              onPress={() => setBottomSheet('speed')}
              activeOpacity={0.8}
            >
              <Text style={styles.quickBtnIcon}>⏱</Text>
              <Text style={styles.quickBtnLabel}>Speed ({playbackSpeed}x)</Text>
            </TouchableOpacity>
          </View>

          {/* Audio Languages Shelf */}
          {dubsList.length > 0 && (
            <View style={styles.dashSection}>
              <Text style={styles.dashSectionTitle}>AVAILABLE AUDIO LANGUAGES</Text>
              <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.chipsRow}>
                {dubsList.map((dub, i) => {
                  const isCurrent = dub.subject_id === currentId;
                  return (
                    <TouchableOpacity
                      key={dub.subject_id || i}
                      style={[styles.audioChip, isCurrent && styles.audioChipActive]}
                      onPress={() => switchDub(dub.subject_id, dub.lang_name)}
                    >
                      <Text style={[styles.audioChipText, isCurrent && styles.audioChipTextActive]}>
                        {isCurrent ? '✓ ' : '🔊 '}{dub.lang_name || 'Dub'}
                      </Text>
                    </TouchableOpacity>
                  );
                })}
              </ScrollView>
            </View>
          )}

          {/* Stream Resolutions Shelf */}
          {playableStreams.length > 0 && (
            <View style={styles.dashSection}>
              <Text style={styles.dashSectionTitle}>SELECT STREAM RESOLUTION</Text>
              <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.chipsRow}>
                {playableStreams.map((s, i) => {
                  const isCurrent = !useIframe && activeStream?.url === s.url;
                  return (
                    <TouchableOpacity
                      key={s.url || i}
                      style={[styles.qualityChip, isCurrent && styles.qualityChipActive]}
                      onPress={() => switchQuality(s)}
                    >
                      <Text style={[styles.qualityChipText, isCurrent && styles.qualityChipTextActive]}>
                        {isCurrent ? '✓ ' : '⚡ '}{s.quality} {s.size_mb ? `(${s.size_mb} MB)` : ''}
                      </Text>
                    </TouchableOpacity>
                  );
                })}
              </ScrollView>
            </View>
          )}

          {/* Cloud Fallback Servers */}
          {fallbackServers.length > 0 && (
            <View style={styles.dashSection}>
              <Text style={styles.dashSectionTitle}>ALTERNATE STREAMING MIRRORS</Text>
              <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.chipsRow}>
                <TouchableOpacity
                  style={[styles.serverChip, !useIframe && styles.serverChipActive]}
                  onPress={() => switchServer('direct')}
                >
                  <Text style={[styles.serverChipText, !useIframe && styles.serverChipTextActive]}>
                    ⚡ MovieBox Direct CDN
                  </Text>
                </TouchableOpacity>
                {fallbackServers.map(srv => {
                  const isCurrent = useIframe && selectedServer === srv.id;
                  return (
                    <TouchableOpacity
                      key={srv.id}
                      style={[styles.serverChip, isCurrent && styles.serverChipActive]}
                      onPress={() => switchServer(srv.id)}
                    >
                      <Text style={[styles.serverChipText, isCurrent && styles.serverChipTextActive]}>
                        ☁️ {srv.name}
                      </Text>
                    </TouchableOpacity>
                  );
                })}
              </ScrollView>
            </View>
          )}

          <View style={{ height: 60 }} />
        </ScrollView>
      )}

      {/* NETFLIX-STYLE BOTTOM SHEET MODAL (Overlays) */}
      <Modal
        visible={bottomSheet !== 'none'}
        transparent
        animationType="slide"
        onRequestClose={() => setBottomSheet('none')}
      >
        <TouchableWithoutFeedback onPress={() => setBottomSheet('none')}>
          <View style={styles.modalBackdrop}>
            <TouchableWithoutFeedback>
              <View style={[styles.bottomSheet, { paddingBottom: insets.bottom + 20 }]}>
                {/* Header */}
                <View style={styles.bottomSheetHeader}>
                  <Text style={styles.bottomSheetTitle}>
                    {bottomSheet === 'audio' && '🔊 Audio Languages & Dubs'}
                    {bottomSheet === 'quality' && '⚡ Video Quality'}
                    {bottomSheet === 'speed' && '⏱ Playback Speed'}
                    {bottomSheet === 'servers' && '☁️ Streaming Servers'}
                    {bottomSheet === 'episodes' && '📺 TV Show Episodes'}
                  </Text>
                  <TouchableOpacity onPress={() => setBottomSheet('none')} style={styles.modalCloseBtn}>
                    <Text style={styles.modalCloseText}>✕</Text>
                  </TouchableOpacity>
                </View>

                {/* AUDIO DUBS LIST */}
                {bottomSheet === 'audio' && (
                  <ScrollView style={styles.sheetList}>
                    {dubsList.length > 0 ? (
                      dubsList.map((dub, i) => {
                        const isSelected = dub.subject_id === currentId;
                        return (
                          <TouchableOpacity
                            key={dub.subject_id || i}
                            style={[styles.sheetRow, isSelected && styles.sheetRowSelected]}
                            onPress={() => switchDub(dub.subject_id, dub.lang_name)}
                          >
                            <Text style={[styles.sheetRowText, isSelected && styles.sheetRowTextSelected]}>
                              🔊 {dub.lang_name || 'Original Audio'}
                            </Text>
                            {isSelected && <Text style={styles.sheetRowCheck}>✓</Text>}
                          </TouchableOpacity>
                        );
                      })
                    ) : (
                      <View style={[styles.sheetRow, styles.sheetRowSelected]}>
                        <Text style={[styles.sheetRowText, styles.sheetRowTextSelected]}>🔊 Original Audio Track</Text>
                        <Text style={styles.sheetRowCheck}>✓</Text>
                      </View>
                    )}
                  </ScrollView>
                )}

                {/* QUALITY LIST */}
                {bottomSheet === 'quality' && (
                  <ScrollView style={styles.sheetList}>
                    {playableStreams.map((s, i) => {
                      const isSelected = !useIframe && activeStream?.url === s.url;
                      return (
                        <TouchableOpacity
                          key={s.url || i}
                          style={[styles.sheetRow, isSelected && styles.sheetRowSelected]}
                          onPress={() => switchQuality(s)}
                        >
                          <Text style={[styles.sheetRowText, isSelected && styles.sheetRowTextSelected]}>
                            ⚡ {s.quality} {s.size_mb ? `(~${s.size_mb} MB)` : ''}
                          </Text>
                          {isSelected && <Text style={styles.sheetRowCheck}>✓</Text>}
                        </TouchableOpacity>
                      );
                    })}
                  </ScrollView>
                )}

                {/* SPEED LIST */}
                {bottomSheet === 'speed' && (
                  <View style={styles.sheetList}>
                    {[0.75, 1.0, 1.25, 1.5, 2.0].map(sp => {
                      const isSelected = playbackSpeed === sp;
                      return (
                        <TouchableOpacity
                          key={sp}
                          style={[styles.sheetRow, isSelected && styles.sheetRowSelected]}
                          onPress={() => changeSpeed(sp)}
                        >
                          <Text style={[styles.sheetRowText, isSelected && styles.sheetRowTextSelected]}>
                            {sp === 1.0 ? '1.0x (Normal)' : `${sp}x`}
                          </Text>
                          {isSelected && <Text style={styles.sheetRowCheck}>✓</Text>}
                        </TouchableOpacity>
                      );
                    })}
                  </View>
                )}

                {/* SERVERS LIST */}
                {bottomSheet === 'servers' && (
                  <ScrollView style={styles.sheetList}>
                    <TouchableOpacity
                      style={[styles.sheetRow, !useIframe && styles.sheetRowSelected]}
                      onPress={() => switchServer('direct')}
                    >
                      <Text style={[styles.sheetRowText, !useIframe && styles.sheetRowTextSelected]}>
                        ⚡ MovieBox Direct CDN (Fastest 1080p MP4)
                      </Text>
                      {!useIframe && <Text style={styles.sheetRowCheck}>✓</Text>}
                    </TouchableOpacity>
                    {fallbackServers.map(srv => {
                      const isSelected = useIframe && selectedServer === srv.id;
                      return (
                        <TouchableOpacity
                          key={srv.id}
                          style={[styles.sheetRow, isSelected && styles.sheetRowSelected]}
                          onPress={() => switchServer(srv.id)}
                        >
                          <Text style={[styles.sheetRowText, isSelected && styles.sheetRowTextSelected]}>
                            ☁️ {srv.name} (Cloud Stream)
                          </Text>
                          {isSelected && <Text style={styles.sheetRowCheck}>✓</Text>}
                        </TouchableOpacity>
                      );
                    })}
                  </ScrollView>
                )}

                {/* EPISODES LIST */}
                {bottomSheet === 'episodes' && (
                  <ScrollView style={styles.sheetList}>
                    {currentSeasonEpisodes.map((ep: any) => {
                      const isCurrent = ep.episode === currentEpisode;
                      return (
                        <TouchableOpacity
                          key={ep.episode}
                          style={[styles.sheetRow, isCurrent && styles.sheetRowSelected]}
                          onPress={() => switchEpisode(currentSeason || 1, ep.episode)}
                        >
                          <Text style={[styles.sheetRowText, isCurrent && styles.sheetRowTextSelected]}>
                            {ep.episode}. {ep.title || `Episode ${ep.episode}`}
                          </Text>
                          {isCurrent && <Text style={styles.sheetRowCheck}>▶ Playing</Text>}
                        </TouchableOpacity>
                      );
                    })}
                  </ScrollView>
                )}
              </View>
            </TouchableWithoutFeedback>
          </View>
        </TouchableWithoutFeedback>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#090a0f' },
  containerFullscreen: { backgroundColor: '#000' },

  playerContainer: {
    width: '100%',
    backgroundColor: '#000',
    position: 'relative',
  },
  webview: { flex: 1, backgroundColor: '#000' },
  centerBox: {
    ...StyleSheet.absoluteFill,
    backgroundColor: '#000',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 12,
  },
  loadingText: { color: '#8e95a5', fontSize: 13, fontWeight: '500' },
  bufferingOverlay: {
    ...StyleSheet.absoluteFill,
    backgroundColor: 'rgba(0,0,0,0.4)',
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 5,
  },
  errorIcon: { fontSize: 36 },
  errorText: { color: '#fca5a5', fontSize: 13, textAlign: 'center', paddingHorizontal: 20 },
  retryBtn: {
    backgroundColor: '#e50914',
    borderRadius: 8,
    paddingHorizontal: 18,
    paddingVertical: 9,
    marginTop: 6,
  },
  retryText: { color: '#fff', fontWeight: '700', fontSize: 13 },

  // Controls Overlay (Netflix Style)
  controlsOverlay: {
    backgroundColor: 'rgba(0,0,0,0.55)',
    justifyContent: 'space-between',
    zIndex: 10,
  },
  topBar: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 14,
    gap: 10,
  },
  iconCircleBtn: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: 'rgba(0,0,0,0.6)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  iconCircleText: { color: '#fff', fontSize: 28, fontWeight: '300', marginTop: -2 },
  topTitleBox: { flex: 1 },
  topMovieTitle: { color: '#fff', fontSize: 13, fontWeight: '700' },
  topMovieSubtitle: { color: '#a1a1aa', fontSize: 11, marginTop: 1 },
  topRightIcons: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  toolChip: {
    backgroundColor: 'rgba(0,0,0,0.65)',
    borderRadius: 6,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.15)',
  },
  toolChipText: { color: '#fff', fontSize: 10, fontWeight: '700' },
  lockIconBtn: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: 'rgba(0,0,0,0.65)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  lockIconText: { fontSize: 14 },

  // Center Controls
  centerControls: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 40,
  },
  seekBtn: {
    alignItems: 'center',
    justifyContent: 'center',
    width: 48,
    height: 48,
  },
  seekBtnIcon: { color: '#fff', fontSize: 26, fontWeight: '600' },
  seekBtnSub: { color: '#fff', fontSize: 10, fontWeight: '800', marginTop: -4 },
  playPauseBtn: {
    width: 62,
    height: 62,
    borderRadius: 31,
    backgroundColor: 'rgba(229,9,20,0.85)',
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#e50914',
    shadowOpacity: 0.5,
    shadowRadius: 10,
    elevation: 6,
  },
  playPauseIcon: { color: '#fff', fontSize: 26, marginLeft: 2 },

  // Bottom Bar
  bottomBar: {
    paddingHorizontal: 14,
    gap: 8,
  },
  scrubberRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  timeText: { color: '#cbd5e1', fontSize: 11, fontWeight: '600', minWidth: 40, textAlign: 'center' },
  scrubberTrack: {
    flex: 1,
    height: 18,
    justifyContent: 'center',
  },
  scrubberFill: {
    height: 4,
    backgroundColor: '#e50914',
    borderRadius: 2,
  },
  scrubberThumb: {
    position: 'absolute',
    width: 12,
    height: 12,
    borderRadius: 6,
    backgroundColor: '#e50914',
    top: 3,
    marginLeft: -6,
  },
  bottomTray: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  bottomTrayLeft: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  trayActionBtn: {
    backgroundColor: 'rgba(0,0,0,0.5)',
    borderRadius: 6,
    paddingHorizontal: 8,
    paddingVertical: 4,
  },
  trayActionText: { color: '#cbd5e1', fontSize: 11, fontWeight: '600' },
  fullscreenToggle: {
    width: 34,
    height: 34,
    alignItems: 'center',
    justifyContent: 'center',
  },
  fullscreenToggleText: { color: '#fff', fontSize: 20, fontWeight: '700' },

  // Locked State
  lockedContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  unlockBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.75)',
    borderRadius: 24,
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.2)',
    gap: 8,
  },
  unlockIcon: { fontSize: 18 },
  unlockText: { color: '#fff', fontSize: 13, fontWeight: '700' },

  // Scrollable Dashboard below video in Portrait
  scrollArea: { flex: 1, backgroundColor: '#090a0f' },
  scrollContent: { padding: 16 },
  metaSection: { marginBottom: 16 },
  movieMainTitle: { color: '#fff', fontSize: 18, fontWeight: '800', lineHeight: 24 },
  badgeRow: { flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: 8, flexWrap: 'wrap' },
  netflixMatchBadge: {
    backgroundColor: 'rgba(70,211,105,0.15)',
    borderRadius: 4,
    paddingHorizontal: 6,
    paddingVertical: 2,
  },
  netflixMatchText: { color: '#46d369', fontSize: 11, fontWeight: '800' },
  qualityTagBadge: {
    backgroundColor: 'rgba(229,9,20,0.15)',
    borderRadius: 4,
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderWidth: 1,
    borderColor: 'rgba(229,9,20,0.3)',
  },
  qualityTagText: { color: '#e50914', fontSize: 10, fontWeight: '800' },
  metaTagBadge: {
    backgroundColor: '#1b1d28',
    borderRadius: 4,
    paddingHorizontal: 6,
    paddingVertical: 2,
  },
  metaTagText: { color: '#94a3b8', fontSize: 10, fontWeight: '600' },

  // Quick Action Bar
  quickBar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-around',
    backgroundColor: '#12141c',
    borderRadius: 12,
    paddingVertical: 12,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.06)',
  },
  quickBtn: { alignItems: 'center', gap: 4 },
  quickBtnIcon: { fontSize: 18 },
  quickBtnLabel: { color: '#94a3b8', fontSize: 10, fontWeight: '600' },

  // Dashboard Sections
  dashSection: { marginBottom: 18 },
  dashSectionTitle: { color: '#71717a', fontSize: 10, fontWeight: '800', letterSpacing: 1, marginBottom: 8 },
  chipsRow: { gap: 8, paddingVertical: 2 },
  audioChip: {
    backgroundColor: '#161822',
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.08)',
  },
  audioChipActive: { backgroundColor: 'rgba(229,9,20,0.2)', borderColor: '#e50914' },
  audioChipText: { color: '#cbd5e1', fontSize: 12, fontWeight: '600' },
  audioChipTextActive: { color: '#fff', fontWeight: '800' },

  qualityChip: {
    backgroundColor: '#161822',
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.08)',
  },
  qualityChipActive: { backgroundColor: 'rgba(229,9,20,0.2)', borderColor: '#e50914' },
  qualityChipText: { color: '#cbd5e1', fontSize: 12, fontWeight: '600' },
  qualityChipTextActive: { color: '#fff', fontWeight: '800' },

  serverChip: {
    backgroundColor: '#161822',
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.08)',
  },
  serverChipActive: { backgroundColor: 'rgba(229,9,20,0.2)', borderColor: '#e50914' },
  serverChipText: { color: '#cbd5e1', fontSize: 12, fontWeight: '600' },
  serverChipTextActive: { color: '#fff', fontWeight: '800' },

  // Bottom Sheet Modal
  modalBackdrop: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.7)',
    justifyContent: 'flex-end',
  },
  bottomSheet: {
    backgroundColor: '#12141c',
    borderTopLeftRadius: 18,
    borderTopRightRadius: 18,
    paddingTop: 16,
    paddingHorizontal: 16,
    maxHeight: '65%',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
  },
  bottomSheetHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingBottom: 14,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255,255,255,0.08)',
  },
  bottomSheetTitle: { color: '#fff', fontSize: 15, fontWeight: '800' },
  modalCloseBtn: {
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: '#262938',
    alignItems: 'center',
    justifyContent: 'center',
  },
  modalCloseText: { color: '#fff', fontSize: 12, fontWeight: '700' },
  sheetList: { paddingVertical: 8 },
  sheetRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 14,
    paddingHorizontal: 12,
    borderRadius: 8,
  },
  sheetRowSelected: { backgroundColor: 'rgba(229,9,20,0.15)' },
  sheetRowText: { color: '#cbd5e1', fontSize: 14, fontWeight: '600' },
  sheetRowTextSelected: { color: '#e50914', fontWeight: '800' },
  sheetRowCheck: { color: '#e50914', fontSize: 14, fontWeight: '800' },
});
