import React, { useEffect, useState, useCallback } from 'react';
import {
  View, Text, FlatList, Image, TouchableOpacity,
  StyleSheet, RefreshControl,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useNavigation, useFocusEffect } from '@react-navigation/native';
import { CONFIG } from '../config';
import { WatchlistService, WatchlistItem } from '../services/watchlist';

export default function WatchlistScreen() {
  const insets = useSafeAreaInsets();
  const navigation = useNavigation<any>();
  const [list, setList] = useState<WatchlistItem[]>([]);
  const [refreshing, setRefreshing] = useState(false);

  const load = useCallback(async () => {
    const items = await WatchlistService.get();
    setList(items);
    setRefreshing(false);
  }, []);

  // Refresh when screen gains focus
  useFocusEffect(useCallback(() => { load(); }, [load]));

  const remove = async (id: string) => {
    await WatchlistService.remove(id);
    setList(prev => prev.filter(i => i.subject_id !== id));
  };

  if (list.length === 0) {
    return (
      <View style={[styles.center, { paddingTop: insets.top }]}>
        <StatusBar style="light" />
        <Text style={styles.emptyIcon}>🔖</Text>
        <Text style={styles.emptyTitle}>Your Watchlist is Empty</Text>
        <Text style={styles.emptySubtitle}>Save movies and shows to watch later</Text>
        <TouchableOpacity style={styles.discoverBtn} onPress={() => navigation.navigate('Home')}>
          <Text style={styles.discoverText}>Discover Content</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      <StatusBar style="light" />
      <Text style={styles.header}>Watchlist</Text>
      <FlatList
        data={list}
        keyExtractor={item => item.subject_id}
        contentContainerStyle={styles.list}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={() => { setRefreshing(true); load(); }}
            tintColor={CONFIG.COLORS.accent}
          />
        }
        renderItem={({ item }) => (
          <TouchableOpacity
            style={styles.row}
            onPress={() => navigation.navigate('Detail', {
              id: item.subject_id,
              title: item.title,
              cover: item.cover,
            })}
            activeOpacity={0.75}
          >
            <Image source={{ uri: item.cover }} style={styles.thumb} resizeMode="cover" />
            <View style={styles.info}>
              <Text style={styles.itemTitle} numberOfLines={2}>{item.title}</Text>
              {item.type && (
                <View style={styles.typeBadge}>
                  <Text style={styles.typeText}>{item.type === 'Series' ? 'TV SHOW' : 'MOVIE'}</Text>
                </View>
              )}
            </View>
            <TouchableOpacity style={styles.removeBtn} onPress={() => remove(item.subject_id)}>
              <Text style={styles.removeIcon}>✕</Text>
            </TouchableOpacity>
          </TouchableOpacity>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: CONFIG.COLORS.bg },
  center: {
    flex: 1,
    backgroundColor: CONFIG.COLORS.bg,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 32,
    gap: 10,
  },
  emptyIcon: { fontSize: 52, marginBottom: 4 },
  emptyTitle: { color: '#fff', fontSize: 18, fontWeight: '700', textAlign: 'center' },
  emptySubtitle: { color: '#71717a', fontSize: 13, textAlign: 'center', lineHeight: 20 },
  discoverBtn: {
    marginTop: 12,
    backgroundColor: CONFIG.COLORS.accent,
    borderRadius: 10,
    paddingHorizontal: 24,
    paddingVertical: 11,
  },
  discoverText: { color: '#fff', fontWeight: '700', fontSize: 14 },

  header: {
    color: '#fff',
    fontSize: 28,
    fontWeight: '800',
    paddingHorizontal: 16,
    paddingTop: 16,
    paddingBottom: 12,
  },
  list: { padding: 16, gap: 10 },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#1b1c26',
    borderRadius: 12,
    overflow: 'hidden',
    marginBottom: 8,
    gap: 12,
    paddingRight: 12,
  },
  thumb: { width: 70, height: 100, backgroundColor: CONFIG.COLORS.card },
  info: { flex: 1, paddingVertical: 10, gap: 8 },
  itemTitle: { color: '#fff', fontSize: 14, fontWeight: '700', lineHeight: 19 },
  typeBadge: {
    alignSelf: 'flex-start',
    backgroundColor: CONFIG.COLORS.accent,
    borderRadius: 5,
    paddingHorizontal: 7,
    paddingVertical: 3,
  },
  typeText: { color: '#fff', fontSize: 9, fontWeight: '800', letterSpacing: 0.5 },
  removeBtn: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: 'rgba(229,9,20,0.12)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  removeIcon: { color: CONFIG.COLORS.accent, fontSize: 13, fontWeight: '700' },
});
