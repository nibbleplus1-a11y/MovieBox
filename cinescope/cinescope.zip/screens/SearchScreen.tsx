import React, { useState, useRef, useCallback } from 'react';
import {
  View, Text, TextInput, FlatList, Image,
  TouchableOpacity, StyleSheet, ActivityIndicator,
  Keyboard,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import { CONFIG } from '../config';
import { api, SearchResult } from '../services/api';

export default function SearchScreen() {
  const insets = useSafeAreaInsets();
  const navigation = useNavigation<any>();
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<SearchResult[]>([]);
  const [loading, setLoading] = useState(false);
  const [searched, setSearched] = useState(false);
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const doSearch = useCallback(async (q: string) => {
    if (!q.trim()) {
      setResults([]);
      setSearched(false);
      return;
    }
    setLoading(true);
    try {
      const data = await api.search(q);
      setResults(data.results || []);
    } catch {
      setResults([]);
    } finally {
      setLoading(false);
      setSearched(true);
    }
  }, []);

  const onChangeText = (text: string) => {
    setQuery(text);
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => doSearch(text), 500);
  };

  const openDetail = (item: SearchResult) => {
    Keyboard.dismiss();
    navigation.navigate('Detail', {
      id: item.subject_id,
      title: item.title,
      cover: item.cover,
    });
  };

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      <StatusBar style="light" />

      {/* Search Bar */}
      <View style={styles.searchRow}>
        <View style={styles.searchBar}>
          <Text style={styles.searchIcon}>🔍</Text>
          <TextInput
            style={styles.input}
            placeholder="Search movies, shows, anime…"
            placeholderTextColor="#52525b"
            value={query}
            onChangeText={onChangeText}
            autoFocus={false}
            returnKeyType="search"
            onSubmitEditing={() => doSearch(query)}
            autoCapitalize="none"
            autoCorrect={false}
          />
          {query.length > 0 && (
            <TouchableOpacity onPress={() => { setQuery(''); setResults([]); setSearched(false); }}>
              <Text style={styles.clearBtn}>✕</Text>
            </TouchableOpacity>
          )}
        </View>
      </View>

      {/* Content */}
      {loading ? (
        <View style={styles.center}>
          <ActivityIndicator size="large" color={CONFIG.COLORS.accent} />
        </View>
      ) : !searched ? (
        <View style={styles.center}>
          <Text style={styles.emptyIcon}>🎬</Text>
          <Text style={styles.emptyTitle}>Find Your Next Watch</Text>
          <Text style={styles.emptySubtitle}>Search any movie, TV show, or anime title</Text>
        </View>
      ) : results.length === 0 ? (
        <View style={styles.center}>
          <Text style={styles.emptyIcon}>🔭</Text>
          <Text style={styles.emptyTitle}>No Results Found</Text>
          <Text style={styles.emptySubtitle}>Try a different title or spelling</Text>
        </View>
      ) : (
        <FlatList
          data={results}
          keyExtractor={item => item.subject_id}
          contentContainerStyle={styles.list}
          showsVerticalScrollIndicator={false}
          renderItem={({ item }) => (
            <TouchableOpacity style={styles.resultRow} onPress={() => openDetail(item)} activeOpacity={0.75}>
              <Image
                source={{ uri: item.cover || 'https://via.placeholder.com/70x100/1b1c26/666' }}
                style={styles.thumb}
                resizeMode="cover"
              />
              <View style={styles.resultInfo}>
                <Text style={styles.resultTitle} numberOfLines={2}>{item.title}</Text>
                <View style={styles.metaRow}>
                  {item.type && (
                    <View style={[styles.tag, { backgroundColor: CONFIG.COLORS.accent }]}>
                      <Text style={styles.tagText}>{item.type === 'Series' ? 'TV SHOW' : 'MOVIE'}</Text>
                    </View>
                  )}
                  {item.year ? <Text style={styles.metaText}>{String(item.year)}</Text> : null}
                  {(() => {
                    const r = item.imdb_rating || item.rating;
                    if (!r || r === 'N/A') return null;
                    const num = typeof r === 'number' ? r : parseFloat(String(r));
                    return isNaN(num) ? null : (
                      <Text style={styles.ratingText}>★ {num.toFixed(1)}</Text>
                    );
                  })()}
                </View>
              </View>
              <Text style={styles.chevron}>›</Text>
            </TouchableOpacity>
          )}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: CONFIG.COLORS.bg,
  },
  searchRow: {
    paddingHorizontal: 16,
    paddingTop: 12,
    paddingBottom: 8,
  },
  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#1b1c26',
    borderRadius: 14,
    paddingHorizontal: 14,
    paddingVertical: 11,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.08)',
    gap: 8,
  },
  searchIcon: { fontSize: 16 },
  input: {
    flex: 1,
    color: '#fff',
    fontSize: 15,
  },
  clearBtn: { color: '#71717a', fontSize: 14, paddingLeft: 6 },

  center: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 32,
    gap: 10,
  },
  emptyIcon: { fontSize: 52, marginBottom: 4 },
  emptyTitle: { color: '#fff', fontSize: 18, fontWeight: '700', textAlign: 'center' },
  emptySubtitle: { color: '#71717a', fontSize: 13, textAlign: 'center', lineHeight: 20 },

  list: { padding: 16, gap: 2 },
  resultRow: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#1b1c26',
    borderRadius: 12,
    overflow: 'hidden',
    marginBottom: 10,
    gap: 12,
    paddingRight: 12,
  },
  thumb: {
    width: 70,
    height: 100,
    backgroundColor: CONFIG.COLORS.card,
  },
  resultInfo: { flex: 1, paddingVertical: 10 },
  resultTitle: { color: '#fff', fontSize: 14, fontWeight: '700', marginBottom: 6, lineHeight: 19 },
  metaRow: { flexDirection: 'row', alignItems: 'center', gap: 8, flexWrap: 'wrap' },
  tag: {
    borderRadius: 5,
    paddingHorizontal: 6,
    paddingVertical: 2,
  },
  tagText: { color: '#fff', fontSize: 9, fontWeight: '800', letterSpacing: 0.5 },
  metaText: { color: '#71717a', fontSize: 12 },
  ratingText: { color: '#fbbf24', fontSize: 12, fontWeight: '700' },
  chevron: { color: '#52525b', fontSize: 22 },
});
